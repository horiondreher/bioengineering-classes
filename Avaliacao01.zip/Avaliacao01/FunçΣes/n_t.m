function [n_t] = n_t(t, n, a_n, b_n)

    n_t = a_n*(1-n) - b_n*n;
    
end

